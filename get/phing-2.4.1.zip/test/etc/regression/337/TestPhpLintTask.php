<?php

require_once 'phing/Task.php';
require_once 'phing/tasks/ext/PhpLintTask.php';

class TestPhpLintTask extends PhpLintTask
{
};

?>