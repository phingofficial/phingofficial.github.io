<?php
echo 'Hello world';
?>
