<?php

class TestClass
{
};

$t = & new TestClass();

?>
