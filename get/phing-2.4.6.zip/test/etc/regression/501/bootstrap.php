<?php
defined('PHING_TEST_BASE') or define('PHING_TEST_BASE', dirname(__FILE__) . '/../../../');
