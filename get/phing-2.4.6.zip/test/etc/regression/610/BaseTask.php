<?php

abstract class BaseTask extends Task
{
};

?>