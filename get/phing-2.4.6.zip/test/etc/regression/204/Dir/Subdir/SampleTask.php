<?php

class Dir_Subdir_SampleTask extends Task
{
    function main()
    {
        $this->log("SampleTask executed!");
    }
};

?>