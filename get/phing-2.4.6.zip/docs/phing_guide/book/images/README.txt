Place all images in this directory.

Do not place images in the chapters/ directory.