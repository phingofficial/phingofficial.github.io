var Chapters = new Array(new Array('chapters/AboutThisBook.html','About this book'),
new Array('chapters/Introduction.html','Introduction'),
new Array('chapters/Setup.html','&#13;
		Setting-Up Phing&#13;
	'),
new Array('chapters/GettingStarted.html','
		Getting Started
	'),
new Array('chapters/ProjectComponents.html','Project Components'),
new Array('chapters/ExtendingPhing.html','&#13;
		Extending Phing&#13;
	'),
new Array('chapters/appendixes/AppendixA-FactSheet.html','Appendix A: Fact Sheet'),
new Array('chapters/appendixes/AppendixB-CoreTasks.html','&#13;
		Appendix B: Core Tasks&#13;
	'),
new Array('chapters/appendixes/AppendixC-OptionalTasks.html','
		Appendix C: Optional Tasks
	'),
new Array('chapters/appendixes/AppendixD-CoreTypes.html','&#13;
		Appendix D: Core Types&#13;
	'),
new Array('chapters/appendixes/AppendixD2-CoreFilters.html','
		Appendix D-2: Core Filters
	'),
new Array('chapters/appendixes/AppendixD3-CoreMappers.html','
		Appendix D-3: Core Mappers
	'),
new Array('chapters/appendixes/AppendixD4-CoreSelectors.html','&#13;
		Appendix D-4: Selectors&#13;
	'),
new Array('chapters/appendixes/AppendixE-ProjectComponents.html','
		Appendix E: Project Components
	'),
new Array('chapters/appendixes/AppendixF-FileFormats.html','
		Appendix F: File Formats
	'),
new Array('chapters/Bibliography.html','Bibliography'));