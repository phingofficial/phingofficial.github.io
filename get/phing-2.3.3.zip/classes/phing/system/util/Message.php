<?php
//
// FIXME. Logger will be renamed to Message, new level is introduces MSG_NOTICE
// Message can handle some more later on
//   - formatted output
//   - sending to dialog or phpgtk whatever
//   - etc
//

